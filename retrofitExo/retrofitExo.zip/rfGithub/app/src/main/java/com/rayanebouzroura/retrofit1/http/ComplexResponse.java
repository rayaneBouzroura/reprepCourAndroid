package com.rayanebouzroura.retrofit1.http;

import java.util.List;

public class ComplexResponse {
    //name , descrip and html_url all strings public
    public String name;
    public String description;

    public String html_url;

    public Long a;
    public String b;
    public List<Long> c;
}
