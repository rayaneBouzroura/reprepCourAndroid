package com.rayanebouzroura.retrofit1.http;

import java.util.List;

public class ComplexResponse {
    //a int , b string c list of int

    public Long a;
    public String b;
    public List<Long> c;
}
