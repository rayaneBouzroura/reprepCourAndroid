package com.rayanebouzroura.recyclerviewb.recyclerView;

public class Secret {
    //need
    //Un champ nom de type String
    public String nom;
    //Un champ date de type java.time.LocalDateTime
    public java.time.LocalDateTime date;
    //Un champ nbGrand de type Long
    public Long nbGrand;

}
